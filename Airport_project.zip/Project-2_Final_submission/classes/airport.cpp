// #include"airport.h"
// using namespace std;
//
// Airport::AirportTable(int size) {       //tablesize = 23 //according to details
//     this -> sizeAir = size;
//     bucketsAir.resize(sizeAir);
// }
//
// int Airport::multiplicativeHash(string codeKey) {      //hash fx using string to find bucket
//     int position = 0;
//     int multiplier = 1;
//     // for(range declaration : range expression) { loop body }
//     // range declaration - name variable of type stored in sequence represented by range expression
//     // range expression - the actual sequence
//     for(auto c : key) {
//         position = (position * multiplier) + c;
//     }
//
//     return position % count;
// }
