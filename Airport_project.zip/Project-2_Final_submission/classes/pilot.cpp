// #include"pilot.h"
// using namespace std;
//
// Pilot::PilotTable(int size) {       //constructor to set size of HT
//     this -> sizePilot = size;
//     bucketsPilot.resize(sizePilot);       //resize vector according to input (23)
// }
//
// int Pilot::moduloHash(int IDKey) {
//     return IDKey % size;      //return bucket/index to store
// }
