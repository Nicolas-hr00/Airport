
#include "Hash.h"

 // void prueba::PrintInfo()
 //  {
 //
 //
 //  }

 // Hash::Hash()
 //   {
 //     for (int i=0; i < BUCKET; i++)
 //      {
 //        table[i] = new Plane;
 //        table[i] = 0;
 //        table[i] -> LastMaint = "None";
 //        table[i] -> LastMaintA = "None";
 //      }
 //   }
   //=============================================================================

   // int Hash::HashFunction(string key)
   //  {
   //    int hash=0;
   //    int index=0;
   //
   //     for (int i=0; i < key.length(); i++)
   //      {
   //         hash = hash + (int)key[i];
   //      }
   //      return hash % BUCKET;
   //  }
   //  //=============================================================================
