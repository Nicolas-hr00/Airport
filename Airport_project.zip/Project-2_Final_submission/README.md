#we would have to access to the main first in order to compile it
#Then, the way this is going to be compile it is going to be like: g++ main.cpp ../classes/*.cpp
#The files are going to be write it in the main where passenger and reservation is.


#For the final submission, none of my teammates actually said anything, I had to create the wiki all by myself and use #
#what I had because none of them pushed anything important. The only person who really contact me and asked me for
#help was ajay, this was because I wrote the main logic that it is being used for the project, so they could use it.
#and I had useful example code. We were actually able to get quite a lot stuff done together.
#as you can see in instructions the Example codes were written by me Nicolas.


#nue..//....
